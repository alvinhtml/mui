// var colors = ['red','orange','yellow','olive','green','teal','blue','violet','purple','pink','brown','blue-sharp'];
//
//
// var ele = document.querySelectorAll(".note-list a"),
//     colorlength = colors.length;
//
//     console.log(ele);
//
//     for (var i = 0; i < ele.length; i++) {
//         ele[i].className = "bg-" + colors[i % colorlength];
//     }
//
// document.querySelector("#header").className = "bg-" + colors[i % colorlength];
